<!DOCTYPE html>
<html>
<head>
    <title>Prospector theater</title>

</head>

<body>
<h3>Hello <?php echo e($name); ?>,</h3>

<p>Your Qr code</p>


<br />
<br />
<br />
<img src="<?php echo e(asset('storage/'.$qr)); ?>" />


<p>Thank you,</p>
<br />
<p>Sanjay Dhali</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\oxigen\project\resources\views/emails/payment.blade.php ENDPATH**/ ?>