
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">

        <div class="card mx-4">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('paid')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name='id' value="<?php echo e($id); ?>">
                    <button class="btn btn-block btn-primary">
                        Paid
                    </button>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\oxigen\project\resources\views/payemnt.blade.php ENDPATH**/ ?>