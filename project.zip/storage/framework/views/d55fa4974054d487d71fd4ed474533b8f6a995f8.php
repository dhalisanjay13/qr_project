<div class="fullwidth-sidebar-container">
    <div class="sidebar bottom-sidebar"></div>
</div>
<footer id="footer" class="site-footer" role="contentinfo">
    <div class="copyright">
        <div class="container">
            <p class="copyright-text"> Copyright &copy; 2019 <a href='https://wordpress.org/themes/directory-starter/' target='_blank' title='Directory Starter'> Directory Starter Theme</a>.</p>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\oxigen\project\resources\views/partials/footer.blade.php ENDPATH**/ ?>