<header id="site-header" class="site-header" role="banner">
    <div class="container">
        <div class="site-logo-wrap">
            <hgroup>
                <h1 class='site-title site-title-no-desc'> <a  style="color:#FFFFFF;" href='<?php echo e(route('home')); ?>' title='<?php echo e(config('app.name', 'Laravel Shops')); ?>' rel='home'><?php echo e(config('app.name', 'Laravel Shops')); ?></a></h1>
            </hgroup>
        </div>
        <nav id="primary-nav" class="primary-nav" role="navigation">
            <ul id="menu-gd-menu" class="menu">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="gd-menu-item menu-item menu-item-type-post_type_archive"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    <li class="gd-menu-item menu-item menu-item-type-post_type_archive"><a href="<?php echo e(route('register')); ?>">Register</a></li>
                <?php else: ?>
                    <li class="gd-menu-item menu-item menu-item-type-post_type_archive"><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
                    <li class="gd-menu-item menu-item menu-item-type-post_type_archive"><a href="#" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">Logout</a></li>
                    <form id="logoutform" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="dt-nav-toggle  dt-mobile-nav-button-wrap"><a href="#primary-nav"><i class="fas fa-bars"></i></a></div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\oxigen\project\resources\views/partials/header.blade.php ENDPATH**/ ?>