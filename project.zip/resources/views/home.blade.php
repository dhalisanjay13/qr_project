@extends('layouts.main')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="content-box content-single">
               
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')

@endsection