<?php

return [
    'site_title' => 'Shops Map',
];
